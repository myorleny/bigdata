spark-submit tarea2.py  viajes_Diber*.json
